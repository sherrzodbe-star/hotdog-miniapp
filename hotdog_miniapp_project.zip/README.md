# American Hot Dog & Burger — Telegram Mini App

## 1. Bot token
BotFather'dan yangi token oling va environment variable orqali kiriting:
`BOT_TOKEN=...`

## 2. Mini App URL
`MINI_APP_URL` HTTPS manzil bo‘lishi kerak. Masalan:
`https://your-domain.com`

## 3. Web papka
`web/` ichidagi `index.html`, `style.css`, `app.js` fayllarini HTTPS hostingga joylashtiring.

## 4. Botni ishga tushirish
```bash
pip install -r requirements.txt
export BOT_TOKEN="YANGI_TOKEN"
export ADMIN_CHAT_ID="8262167046"
export GROUP_CHAT_ID="-1004463040469"
export MINI_APP_URL="https://your-domain.com"
python bot.py
```

Windows PowerShell:
```powershell
$env:BOT_TOKEN="YANGI_TOKEN"
$env:ADMIN_CHAT_ID="8262167046"
$env:GROUP_CHAT_ID="-1004463040469"
$env:MINI_APP_URL="https://your-domain.com"
python bot.py
```

## 5. Telegram BotFather
BotFather → bot → Menu Button / Configure Menu Button orqali Mini App URL'ni ulang.
Shuningdek, `/setmenubutton` sozlamasidan foydalanishingiz mumkin.

## Muhim
Eski PDF'dagi bot tokenini ishlatmang. U ochiq ko‘rinib qolgan; BotFather orqali tokenni yangilang.
