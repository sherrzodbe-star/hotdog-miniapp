import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "PASTE_NEW_BOT_TOKEN_HERE")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "8262167046")
GROUP_CHAT_ID = os.getenv("GROUP_CHAT_ID", "-1004463040469")
MINI_APP_URL = os.getenv("MINI_APP_URL", "https://YOUR-DOMAIN.example")

MENU = {
    "classic_burger": ("Classic Burger", 35000, "🍔"),
    "dabil_burger": ("Dabil Burger", 45000, "🍔"),
    "chicken_burger": ("Chicken Burger", 35000, "🍔"),
    "kofte_burger": ("Kofte Burger", 45000, "🍔"),
    "ultra_hotdog": ("Ultra Hot Dog", 38000, "🌭"),
    "bolshoy_hotdog": ("Bolshoy Hot Dog", 33000, "🌭"),
    "sredniy_hotdog": ("Sredniy Hot Dog", 25000, "🌭"),
    "malenkiy_hotdog": ("Malenkiy Hot Dog", 15000, "🌭"),
    "clab_sendvich": ("Clab Sendvich", 40000, "🥪"),
    "obichniy_hotdog": ("Obichniy Hot Dog", 15000, "🌭"),
    "koroleviski_hotdog": ("Koroleviski Hot Dog", 25000, "🌭"),
    "corn_hotdog_1": ("Corn Hot Dog (1 sosiska)", 18000, "🌽"),
    "corn_hotdog_2": ("Corn Hot Dog (2 sosiska)", 28000, "🌽"),
}

def price(n):
    return f"{n:,}".replace(",", " ") + " so'm"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🌭 MENYUNI OCHISH", web_app={"url": MINI_APP_URL})],
        [InlineKeyboardButton("📍 Manzil", callback_data="address")]
    ])
    await update.message.reply_text(
        "🌭 *American Hot Dog & Burger*\n\n"
        "Buyurtmangizni Mini App orqali qulay tarzda bering.\n\n"
        "📍 Termiz shahri, Cola restoran ro‘parasi\n"
        "📞 +998 95 156 82 88 / +998 95 147 83 88",
        parse_mode="Markdown",
        reply_markup=kb
    )

async def address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.message.reply_text(
        "📍 Termiz shahri, Cola restoran ro‘parasi\n"
        "📞 +998 95 156 82 88 / +998 95 147 83 88"
    )

async def web_app_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.effective_message.web_app_data.data
    try:
        order = __import__("json").loads(data)
    except Exception:
        await update.effective_message.reply_text("❌ Buyurtma ma'lumotini o‘qib bo‘lmadi.")
        return

    lines = [
        "🆕 YANGI BUYURTMA (Mini App)",
        f"👤 Mijoz: {order.get('name','-')}",
        f"📞 Tel: {order.get('phone','-')}",
        f"💳 To‘lov: {order.get('payment','-')}",
        "",
        "🛒 Buyurtma:"
    ]
    for item in order.get("items", []):
        lines.append(f"• {item['name']} x{item['qty']} = {price(item['sum'])}")
    lines.append(f"\n💰 Jami: {price(order.get('total', 0))}")
    if order.get("note"):
        lines.append(f"📝 Izoh: {order['note']}")

    text = "\n".join(lines)
    for chat_id in (ADMIN_CHAT_ID, GROUP_CHAT_ID):
        try:
            await context.bot.send_message(chat_id=chat_id, text=text)
        except Exception as e:
            logger.exception("Buyurtmani yuborishda xatolik: %s", e)

    await update.effective_message.reply_text("✅ Buyurtmangiz qabul qilindi! Tez orada tayyor bo‘ladi. 🌭")

def main():
    if BOT_TOKEN == "PASTE_NEW_BOT_TOKEN_HERE":
        raise RuntimeError("BOT_TOKEN ni environment variable orqali kiriting.")
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, web_app_data))
    from telegram.ext import CallbackQueryHandler
    app.add_handler(CallbackQueryHandler(address, pattern="^address$"))
    app.run_polling()

if __name__ == "__main__":
    main()
